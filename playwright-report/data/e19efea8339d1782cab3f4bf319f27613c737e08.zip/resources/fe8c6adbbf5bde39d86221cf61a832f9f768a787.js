(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_095d66d8._.js",
  "static/chunks/src_app_dashboard_layout_tsx_e49293ea._.js"
],
    source: "dynamic"
});

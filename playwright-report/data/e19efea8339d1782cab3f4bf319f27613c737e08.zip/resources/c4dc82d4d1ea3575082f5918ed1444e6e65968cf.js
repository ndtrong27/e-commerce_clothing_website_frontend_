(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__40445227._.css",
  "static/chunks/node_modules_e25c467d._.js",
  "static/chunks/src_a865d07b._.js"
],
    source: "dynamic"
});
